import React, { useState } from 'react'

const SAMPLE_PRODUCTS = [
  { id: 101, title: "Men's Casual T-Shirt", price: 499, desc: "100% cotton, multiple colors" },
  { id: 102, title: "Canvas Tote Bag", price: 249, desc: "Recycled cotton, 35×40cm" },
  { id: 103, title: "LED Desk Lamp", price: 799, desc: "Adjustable brightness, USB powered" },
  { id: 104, title: "Silk Scarf", price: 599, desc: "Lightweight, elegant patterns" },
  { id: 105, title: "Stainless Steel Bottle", price: 399, desc: "1L, keeps cold for 12 hours" },
  { id: 106, title: "Wireless Earbuds", price: 1299, desc: "Bluetooth 5.2, long battery" },
  { id: 107, title: "Leather Wallet", price: 699, desc: "Compact, multiple slots" },
  { id: 108, title: "Ceramic Mug", price: 249, desc: "Handmade, 350ml" },
  { id: 109, title: "Scented Candle (250g)", price: 349, desc: "Long-lasting fragrance" },
  { id: 110, title: "Travel Organizer", price: 549, desc: "Keeps cables and accessories tidy" }
]

export default function App(){
  const [products] = useState(SAMPLE_PRODUCTS)
  const [query, setQuery] = useState('')
  const [cart, setCart] = useState([])
  const [selected, setSelected] = useState(null)

  const filtered = products.filter(p => 
    p.title.toLowerCase().includes(query.toLowerCase()) || p.desc.toLowerCase().includes(query.toLowerCase())
  )

  function addToCart(product){
    setCart(prev => {
      const found = prev.find(i => i.id === product.id)
      if(found) return prev.map(i => i.id === product.id ? {...i, qty: i.qty + 1} : i)
      return [...prev, {...product, qty: 1}]
    })
  }

  function updateQty(id, qty){
    setCart(prev => prev.map(i => i.id === id ? {...i, qty: Math.max(1, qty)} : i))
  }

  function removeFromCart(id){
    setCart(prev => prev.filter(i => i.id !== id))
  }

  const subtotal = cart.reduce((s, it) => s + it.price * it.qty, 0)

  function checkout(){
    alert('Checkout - total ₹' + subtotal + '. This demo is not connected to payments. I can integrate Razorpay next.')
    setCart([])
  }

  return (
    <div className="page">
      <header className="header">
        <div>
          <h1 className="brand">TSA Shop</h1>
          <div className="tag">TSA GROUPS</div>
        </div>
        <div className="controls">
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search products..." className="search" />
          <button className="cart-btn">Cart ({cart.reduce((s, it) => s + it.qty, 0)})</button>
        </div>
      </header>

      <main className="container">
        <section className="products">
          {filtered.map(p => (
            <article key={p.id} className="card">
              <div className="img">Image</div>
              <h3>{p.title}</h3>
              <p className="desc">{p.desc}</p>
              <div className="row">
                <div className="price">₹{p.price}</div>
                <div className="actions">
                  <button onClick={() => setSelected(p)} className="btn">View</button>
                  <button onClick={() => addToCart(p)} className="btn primary">Add</button>
                </div>
              </div>
            </article>
          ))}
        </section>

        <aside className="sidebar">
          <div className="cart-box">
            <h4>Cart Summary</h4>
            {cart.length === 0 ? <p className="muted">No items yet — add some!</p> : (
              <div>
                {cart.map(item => (
                  <div key={item.id} className="cart-item">
                    <div>
                      <div className="item-title">{item.title}</div>
                      <div className="muted">₹{item.price} x {item.qty}</div>
                    </div>
                    <div className="cart-actions">
                      <input type="number" value={item.qty} onChange={e => updateQty(item.id, Number(e.target.value))} className="qty" />
                      <button onClick={() => removeFromCart(item.id)} className="link">Remove</button>
                    </div>
                  </div>
                ))}
                <div className="subtotal">
                  <div>Subtotal</div>
                  <div className="bold">₹{subtotal}</div>
                </div>
                <button onClick={checkout} className="btn block primary">Checkout</button>
              </div>
            )}
          </div>

          <div className="info">
            <p><strong>Contact:</strong> +91 9943379617</p>
            <p>Payment: Razorpay (integration available)</p>
          </div>
        </aside>
      </main>

      {selected && (
        <div className="modal" onClick={() => setSelected(null)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <h3>{selected.title}</h3>
            <p className="desc">{selected.desc}</p>
            <div className="row">
              <div className="price">₹{selected.price}</div>
              <div>
                <button onClick={() => addToCart(selected)} className="btn primary">Add to cart</button>
                <button onClick={() => setSelected(null)} className="btn">Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <footer className="footer">
        <div>TSA GROUPS — Tsashop</div>
        <div>Made with ❤️</div>
      </footer>
    </div>
  )
}
